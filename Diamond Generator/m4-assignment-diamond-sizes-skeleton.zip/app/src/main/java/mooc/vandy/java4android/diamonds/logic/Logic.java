package mooc.vandy.java4android.diamonds.logic;

import mooc.vandy.java4android.diamonds.ui.OutputInterface;

/**
 * This is where the logic of this App is centralized for this assignment.
 * <p>
 * The assignments are designed this way to simplify your early
 * Android interactions.  Designing the assignments this way allows
 * you to first learn key 'Java' features without having to beforehand
 * learn the complexities of Android.
 */
public class Logic
       implements LogicInterface {
    /**
     * This is a String to be used in Logging (if/when you decide you
     * need it for debugging).
     */
    public static final String TAG = Logic.class.getName();

    /**
     * This is the variable that stores our OutputInterface instance.
     * <p>
     * This is how we will interact with the User Interface [MainActivity.java].
     * <p>
     * It is called 'out' because it is where we 'out-put' our
     * results. (It is also the 'in-put' from where we get values
     * from, but it only needs 1 name, and 'out' is good enough).
     */
    private OutputInterface mOut;

    /**
     * This is the constructor of this class.
     * <p>
     * It assigns the passed in [MainActivity] instance (which
     * implements [OutputInterface]) to 'out'.
     */
    public Logic(OutputInterface out){
        mOut = out;
    }

    /**
     * This is the method that will (eventually) get called when the
     * on-screen button labeled 'Process...' is pressed.
     */
    public void process(int size) {

        // TODO -- add your code here

        int height, width;
        height = 2 * size;
        width = 2 * size + 1;
        int count = 0; // For storing the no. of dashes to print

        for (int i = 0; i <= height; i++) {

            if (i == 0 || i == height) {
                // Executes for the first and last rows

                for (int j = 0; j <= width; j++) {

                    // For printing the corners
                    if (j == 0 || j == width) {
                        mOut.print("+");
                    } else {
                        mOut.print("-");
                    }
                }

            } else {
                // Proceed with printing middle rows

                char start, end; // used to store the ASCII characters

                if (i < height / 2) {
                    start = '/';
                    end = '\\';
                } else if (i == height / 2) {
                    start = '<';
                    end = '>';
                } else {
                    start = '\\';
                    end = '/';
                }

                // Calculating the no. of spaces that are to be printed at sides
                int noOfSpaces = width / 2 - i;
                if (noOfSpaces < 0)
                    noOfSpaces *= -1;

                // For printing starting pipe
                mOut.print("|");

                // For printing starting spaces
                for (int k = 0; k < noOfSpaces; k++) {
                    mOut.print(" ");
                }

                // Printing the diamond's left edge
                mOut.print(start);

                // Printing the pattern in between
                for (int k = 0; k < count; k++)
                    mOut.print(i % 2 == 0 ? "-" : "=");

                // Printing the diamond's right edge
                mOut.print(end);

                // For printing ending spaces
                for (int k = 0; k < noOfSpaces; k++) {
                    mOut.print(" ");
                }

                // For printing ending pipe
                mOut.print("|");

                // Incrementing the no. of dashes to print
                if (i < height / 2)
                    count += 2;
                else
                    count -= 2;
            }

            mOut.print('\n');

        }
    }
}
