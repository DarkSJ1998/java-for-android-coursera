package mooc.vandy.java4android.calculator.logic;

abstract class CalcOperation {

    // Instance Variables
    int argumentOne = 0;
    int argumentTwo = 0;

    // Declaration of method to perform the calculations
    abstract void calculate();

}
